# Lipstick Market Dataset

This repository contains a structured dataset derived from public information about the **Global Lipstick Market**.  
The dataset format is similar to other market‑dataset repositories on GitHub.

## Files Included
- `market_overview.csv` – Market size & CAGR by year  
- `segmentation.csv` – Market segmentation data  
- `metadata.json` – Dataset metadata & source  
- `README.md` – Documentation  

## Source  
Data referenced from: https://www.nextmsc.com/report/lipstick-market-rc3580
